মেধার লড়াই (Battle of Brains) — Android APK Build Project

এই ফোল্ডারটি Android Studio/ক্লাউড CI দিয়ে APK তৈরির সোর্স প্রজেক্ট। এটি নিজে APK ফাইল নয়।

অ্যাপের বৈশিষ্ট্য
- বাংলা ও English ভাষা
- প্রতি লেভেলে ১০টি প্রশ্ন
- সঠিক উত্তরে +১, ভুল উত্তরে −০.২৫, উত্তর না দিলে ০
- ১০টি প্রশ্ন শেষ হলে পরের লেভেল আনলক
- পয়েন্ট, লেভেল ও প্রশ্ন ডিভাইসের Local Storage-এ সংরক্ষণ
- অ্যাডমিন প্যানেল থেকে প্রশ্ন যোগ, সম্পাদনা ও মুছে ফেলা
- JSON প্রশ্ন ব্যাকআপ ডাউনলোড ও পুনরুদ্ধার

প্রজেক্ট যাচাই
- MainActivity-তে Android assets-এর WebView access চালু রাখা হয়েছে, যাতে index.html লোড হয়।
- JavaScript syntax check সফল হয়েছে।
- এই কাজের পরিবেশে Android SDK, Gradle এবং Android build tools নেই; তাই এখানে APK compile/install test করা সম্ভব হয়নি।

GitHub Actions build
- .github/workflows/android-apk.yml রয়েছে।
- প্রজেক্টের সব ফাইল repository-র root-এ রাখতে হবে (ZIP ফাইল হিসেবে নয়; extract করে)।
- main/master branch-এ push করলে অথবা Actions থেকে “Build Android APK” workflow চালালে debug APK তৈরি হবে।
- সফল হলে Actions run-এর Artifacts থেকে “medhar-lorai-debug-apk” ডাউনলোড করা যাবে।

Android Studio build
- Android Studio-তে এই প্রজেক্ট খুলুন।
- SDK Platform 35 ও Gradle plugin 8.7.3 সেটআপ/Sync সম্পন্ন করুন।
- Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
- APK: app/build/outputs/apk/debug/app-debug.apk

সীমাবদ্ধতা
- এটি বর্তমানে অফলাইন প্রোটোটাইপ; কেন্দ্রীয় সার্ভার/অ্যাকাউন্ট/অনলাইন লিডারবোর্ড নেই।
- বিজ্ঞাপন ও পেইড ফিচার যুক্ত হয়নি।
- প্রশ্নের ডেটা ডিভাইসেই থাকে; একাধিক ডিভাইসে স্বয়ংক্রিয়ভাবে সিঙ্ক হয় না।
